import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, CheckCircle2, FileText, ArrowRight } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

function FileUpload({ label }: { label: string }) {
  return (
    <div className="space-y-2">
      <Label className="text-xs font-bold uppercase text-slate-500">{label}</Label>
      <div className="border-2 border-dashed border-slate-200 rounded p-6 flex flex-col items-center justify-center text-center hover:bg-slate-50 transition-colors cursor-pointer bg-white">
        <Upload className="h-6 w-6 text-[#003366] mb-2" />
        <p className="text-[10px] font-bold text-slate-600 uppercase">Upload Document</p>
        <p className="text-[9px] text-slate-400 mt-1">MAX 10MB (PDF/JPG)</p>
        <Input type="file" className="hidden" />
      </div>
    </div>
  );
}

const serviceDetails = [
  { 
    id: "agreement", 
    title: "Agreement", 
    description: "Legal preparation of various types of agreements.", 
    docs: ["Identity Proof (Aadhaar/PAN)", "Agreement Draft", "Address Proof", "Witness Details", "NOC / P1/P2 Khasra", "Mutation of Land Record"] 
  },
  { 
    id: "sales-deed", 
    title: "Sales Deed", 
    description: "Official document for the sale and transfer of property.", 
    docs: ["Duly Signed Sale Deed", "Title Deed (Proof of Ownership)", "Previous Sale Deed", "Property Tax Receipts", "Encumbrance Certificate", "Identity & Address Proof (Buyer + Seller)", "PAN Card (Both Parties)", "Property Photos (Geotagged)", "NOC / P1/P2 Khasra", "Mutation of Land Record"] 
  },
  { 
    id: "lease-renewal", 
    title: "Renewal of Lease Deed", 
    description: "Hassle-free extension of your existing lease deeds.", 
    docs: ["Lease Agreement (Terms/Duration/Rent)", "Title Deed (Lessor's Ownership Proof)", "Identity & Address Proof (Lessor + Lessee)", "Property Tax Receipts", "NOC (if property is mortgaged)", "Previous Lease Deed"] 
  },
  { 
    id: "release-deed", 
    title: "Release Deed", 
    description: "Legal document to renounce rights in a property.", 
    docs: ["Family Member IDs", "Original Property Papers", "Affidavit", "Relinquishing Member's Consent", "NOC / P1/P2 Khasra", "Mutation of Land Record"] 
  },
  { 
    id: "gift-deed", 
    title: "Gift Deed", 
    description: "Transfer of property ownership as a gift legally.", 
    docs: ["Executed Gift Deed", "Title Deed (Donor's Ownership Proof)", "Identity Proof (Donor + Donee)", "Relationship Proof", "Property Tax Receipts", "Valuation ID", "NOC / P1/P2 Khasra", "Mutation of Land Record"] 
  },
  { 
    id: "will-deed", 
    title: "Will Deed", 
    description: "Legal declaration of a person's intentions regarding their property after death.", 
    docs: ["Original Will (Signed Copy)", "Identity Proof (Testator)", "Property Details (Title Deed/Khasra)", "Witness Details (2 Witnesses Required)", "Medical Certificate (Sound Mind Proof)", "NOC / P1/P2 Khasra", "Mutation of Land Record"] 
  },
  { 
    id: "equitable-mortgage", 
    title: "Equitable Mortgage", 
    description: "Creation of mortgage by deposit of title deeds.", 
    docs: ["Original Title Deeds", "Bank Sanction Letter", "Identity Proof", "Address Proof", "NOC / P1/P2 Khasra", "Mutation of Land Record"] 
  },
  { 
    id: "mutation", 
    title: "Mutation of Land Property", 
    description: "Update of title ownership in the local land records.", 
    docs: ["Registered Sale Deed / Gift Deed", "P1/P2 Khasra (Current Land Record)", "Khasra Number Details", "Identity Proof (New Owner)", "Death Certificate (for inheritance)", "Will / Succession Certificate (if inheritance)", "NOC / P1/P2 Khasra", "Mutation of Land Record"] 
  }
];

export default function Services() {
  return (
    <div className="min-h-screen bg-[#f4f7f9]">
      <Navbar />
      
      <div className="bg-[#003366] py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-2xl font-bold text-white uppercase tracking-wider text-center">
            Online Services
          </h1>
          <p className="mt-2 text-white/70 text-sm text-center max-w-2xl mx-auto">
            Access government real estate services through our simplified interface.
          </p>
        </div>
      </div>

      <main className="container mx-auto px-4 py-12">
        <div className="grid gap-8 lg:grid-cols-4">
          <div className="lg:col-span-1 space-y-2">
            <h3 className="text-xs font-bold text-[#003366] uppercase tracking-widest mb-4">Categories</h3>
            <div className="sticky top-24 space-y-2">
              {serviceDetails.map((service) => (
                <a
                  key={service.id}
                  href={`#${service.id}`}
                  className="flex items-center justify-between p-3 bg-white border rounded shadow-sm hover:border-[#003366] transition-all group"
                >
                  <span className="text-[11px] font-bold text-slate-700 uppercase">{service.title}</span>
                  <ArrowRight className="h-3 w-3 text-slate-300 group-hover:text-[#003366]" />
                </a>
              ))}
            </div>
          </div>

          <div className="lg:col-span-3">
            <div className="bg-[#ffc107]/10 border-l-4 border-[#ffc107] p-6 mb-12 rounded-r-lg">
              <div className="flex gap-4">
                <div className="bg-[#ffc107] p-2 rounded-full h-fit mt-1">
                  <FileText className="h-4 w-4 text-[#003366]" />
                </div>
                <div>
                  <h3 className="text-[#003366] font-bold uppercase text-sm mb-2 tracking-wide">Important Property Document Requirement</h3>
                  <p className="text-[#003366]/80 text-xs leading-relaxed">
                    If the property is owned by <span className="font-bold">Nagar Nigam, Housing Board, or JDA</span>, kindly upload the <span className="font-bold uppercase underline">NOC</span>. Otherwise, upload <span className="font-bold uppercase underline">P1/P2 Khasra</span> and <span className="font-bold uppercase underline">Mutation of Land Record</span>. This is mandatory for all services except Lease Deed Renewal.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="space-y-12">
              {serviceDetails.map((service) => (
                <section key={service.id} id={service.id} className="scroll-mt-24">
                  <Card className="sampada-card">
                    <CardHeader className="border-b border-slate-100 bg-slate-50/50">
                      <div className="flex items-center gap-3">
                        <div className="bg-[#003366] p-2 rounded text-white">
                          <FileText className="h-5 w-5" />
                        </div>
                        <div>
                          <CardTitle className="text-lg font-bold text-[#003366] uppercase">{service.title}</CardTitle>
                          <CardDescription className="text-xs">{service.description}</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-8 space-y-8">
                      <div className="grid gap-4 bg-blue-50/50 p-4 rounded border border-blue-100">
                        <h4 className="text-xs font-bold text-[#003366] uppercase flex items-center gap-2">
                          <CheckCircle2 className="h-4 w-4" />
                          Required Documents Checklist
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {service.docs.map(doc => (
                            <span key={doc} className="bg-white px-3 py-1 rounded-full text-[10px] font-bold text-slate-600 border border-slate-200">
                              {doc}
                            </span>
                          ))}
                        </div>
                      </div>
                      
                      <div className="grid gap-6 sm:grid-cols-3">
                        {service.docs.map((doc, i) => (
                          <FileUpload key={i} label={doc} />
                        ))}
                      </div>

                      <div className="pt-4">
                        <Button className="w-full sampada-btn-primary py-6 uppercase tracking-widest font-bold">
                          Proceed to Application
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </section>
              ))}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
